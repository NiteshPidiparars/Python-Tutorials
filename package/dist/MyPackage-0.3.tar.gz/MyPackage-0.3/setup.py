from setuptools import setup
setup(name="MyPackage",
      version="0.3",
      description="This is code with nick package",
      long_description="This is a very very long description",
      author="Harry",
      packages=['MyPackage'],
      install_requires=[])
